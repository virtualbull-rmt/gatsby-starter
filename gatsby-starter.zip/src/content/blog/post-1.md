---
title: "Sample Blog Post"
date: "2024-06-21"
path: "sample-blog"
image: "/fotro.JPG"
---

# Sample Blog Post

Here is some content for your blog post.

![Image Alt Text](/fotro.JPG)
